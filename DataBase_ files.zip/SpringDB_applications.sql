-- MySQL dump 10.13  Distrib 5.7.27, for Linux (x86_64)
--
-- Host: localhost    Database: SpringDB
-- ------------------------------------------------------
-- Server version	5.7.27-0ubuntu0.18.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `applications`
--

DROP TABLE IF EXISTS `applications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `applications` (
  `applicant_no` int(11) NOT NULL,
  `board` varchar(255) DEFAULT NULL,
  `college_ch1` varchar(255) DEFAULT NULL,
  `count` int(11) NOT NULL,
  `dept_choice` varchar(255) DEFAULT NULL,
  `gpa` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `percentage` int(11) NOT NULL,
  `school_name` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`applicant_no`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `applications`
--

LOCK TABLES `applications` WRITE;
/*!40000 ALTER TABLE `applications` DISABLE KEYS */;
INSERT INTO `applications` VALUES (2,'cbse','CMRIT',1,'it','8','sahithya','sahi04',89,'CPS','accepted'),(5,'ssc','CMRTC',2,'cse',NULL,'manaswini','manas',98,'JGS','accepted'),(6,'cbse','CMRCET',2,'cse','8','neel','neel',89,'zxfvsdg','accepted'),(7,'cbse','CMRTC',2,'cse','9','dhanush','dhanush',99,'schs','accepted'),(9,'ssc','CMRPharm',1,'it',NULL,'akhil','akhil',98,'CPS','accepted'),(10,'ssc','CMRIT',2,'mech',NULL,'akash','akash',90,'ABCD','rejected'),(11,'cbse','CMRIT',1,'it','10','sahith','sahith',100,'BGKH','accepted'),(12,'cbse','CMREC',2,'ece','7','abhishek','abhishek',77,'DJFA','rejected'),(13,'cbse','CMRIT',2,'cse','9','charan','charan',98,'WPS','rejected'),(14,'cbse','CMRTC',1,'cse','8','sapna','sapna',87,'GHDH','accepted'),(15,'ssc','CMRTC',0,'cse',NULL,'naveen','naveen',99,'SDFG','pending'),(16,'ssc','CMRTC',1,'cse',NULL,'santhosh','santhosh',90,'KJHG','pending'),(17,'cbse','CMREC',0,'cse','7','soni','soni',80,'FTGF','pending'),(18,'cbse','CMRTC',1,'cse','9','shravya','shravya',97,'FGYT','pending'),(19,'ssc','CMRCET',1,'ece',NULL,'neha','neha',89,'CPS','rejected');
/*!40000 ALTER TABLE `applications` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-09-03  9:45:39
